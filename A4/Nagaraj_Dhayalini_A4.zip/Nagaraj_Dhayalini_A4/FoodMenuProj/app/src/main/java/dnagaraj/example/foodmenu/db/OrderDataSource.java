package dnagaraj.example.foodmenu.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

import dnagaraj.example.foodmenu.models.OrderModel;

/**
 * Created by dhayalini on 27-02-2016.
 */
public class OrderDataSource {
    // Database fields
    private SQLiteDatabase database;
    private AppSQLiteHelper dbHelper;
    private String[] allColumns = { AppSQLiteHelper.COLUMN_ID,
            AppSQLiteHelper.COLUMN_ITEMS, AppSQLiteHelper.COLUMN_PRICE,AppSQLiteHelper.COLUMN_TIMESTAMP };

    public OrderDataSource(Context context) {
        dbHelper = new AppSQLiteHelper(context);
    }

    public void open() throws SQLException {
        database = dbHelper.getWritableDatabase();
    }

    public void close() {
        dbHelper.close();
    }

    public OrderDBModel insertOrder(OrderDBModel order) {
        ContentValues values = new ContentValues();
        values.put(AppSQLiteHelper.COLUMN_ITEMS, order.getFoodItems());
        values.put(AppSQLiteHelper.COLUMN_PRICE,order.getTotalPrice());
        values.put(AppSQLiteHelper.COLUMN_TIMESTAMP, order.getTimeStamp());
        long insertId = database.insert(AppSQLiteHelper.TABLE_ORDERS, null,
                values);
        Cursor cursor = database.query(AppSQLiteHelper.TABLE_ORDERS,
                allColumns, AppSQLiteHelper.COLUMN_ID + " = " + insertId, null,
                null, null, null);
        cursor.moveToFirst();
        OrderDBModel newOrder = cursorToOrder(cursor);
        cursor.close();
        return newOrder;
    }

    private OrderDBModel cursorToOrder(Cursor cursor) {
        OrderDBModel order = new OrderDBModel();
        order.setId(cursor.getInt(0));
        order.setFoodItems(cursor.getString(1));
        order.setTimeStamp(cursor.getString(3));
        order.setTotalPrice(cursor.getFloat(2));
        return order;
    }

    public List<OrderDBModel> getAllOrders() {
        List<OrderDBModel> OrderDBModels = new ArrayList<OrderDBModel>();

        Cursor cursor = database.query(AppSQLiteHelper.TABLE_ORDERS,
                allColumns, null, null, null, null, null);

        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            OrderDBModel OrderDBModel = cursorToOrder(cursor);
            OrderDBModels.add(OrderDBModel);
            cursor.moveToNext();
        }
        // make sure to close the cursor
        cursor.close();
        return OrderDBModels;
    }
}
