package dnagaraj.example.foodmenu.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import dnagaraj.example.foodmenu.R;
import dnagaraj.example.foodmenu.adapters.OrderAdapter;
import dnagaraj.example.foodmenu.db.OrderDBModel;
import dnagaraj.example.foodmenu.models.OrderModel;

public class OrderActivity extends AppCompatActivity implements View.OnClickListener{

    ListView lsOrders;
    Button btnConfirm, btnCancel;
    float totalAmount;
    ArrayList<OrderModel> orders;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        orders = (ArrayList<OrderModel>) getIntent().getSerializableExtra("orders");
        totalAmount = getIntent().getFloatExtra("total_price",0F);
        totalAmount = roundTwoDecimals(totalAmount);
        orders.add(new OrderModel("Total",totalAmount));
        OrderAdapter adapter = new OrderAdapter(orders,this);
        lsOrders = (ListView)findViewById(R.id.listOrders);
        btnCancel = (Button) findViewById(R.id.btnCancel);
        btnConfirm = (Button) findViewById(R.id.btnConfirm);
         btnCancel.setOnClickListener(this);
        btnConfirm.setOnClickListener(this);
        lsOrders.setAdapter(adapter);
    }

    @Override
    public void onClick(View v) {
        if(v.getId() == R.id.btnCancel){
            setResult(RESULT_CANCELED);
            finish();
        }else if(v.getId() == R.id.btnConfirm){
            Intent result = new Intent();
            OrderDBModel dbOrders = new OrderDBModel();
            dbOrders.setTotalPrice(totalAmount);
            String timeStamp = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date());
            dbOrders.setTimeStamp(timeStamp);
            if(orders != null){
                String ordersString = "";
                for(int i = 0; i<orders.size() - 1; i++){//Leaving last row as it has 'total'
                    OrderModel order = orders.get(i);
                    if("".equals(ordersString)){
                        ordersString = order.getFoodName();
                    }else{
                        ordersString = ordersString+", "+order.getFoodName();
                    }
                }
                dbOrders.setFoodItems(ordersString);
            }
            result.putExtra("orders_to_insert_into_db",dbOrders);
            result.putExtra("total_price", totalAmount);
            setResult(RESULT_OK,result);
            finish();
        }
    }
    float roundTwoDecimals(float d) {
        DecimalFormat twoDForm = new DecimalFormat("#.##");
        twoDForm.setRoundingMode(RoundingMode.HALF_UP);
        return Float.valueOf(twoDForm.format(d));
    }

}
