package dnagaraj.example.foodmenu.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

import dnagaraj.example.foodmenu.R;
import dnagaraj.example.foodmenu.models.FoodItemModel;
import dnagaraj.example.foodmenu.models.OrderModel;

/**
 * Created by dhayalini on 12-02-2016.
 */
public class OrderAdapter extends BaseAdapter{

    ArrayList<OrderModel> orders;
    Context context;
    private LayoutInflater inflater;
    public OrderAdapter(ArrayList<OrderModel> orders, Context context){
        this.orders = orders;
        this.context = context;
        inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return orders.size();
    }

    @Override
    public Object getItem(int position) {
        return orders.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        OrderItemHolder holder = null;
       if(convertView == null){
           convertView = inflater.inflate(R.layout.item_order,parent,false);
           holder = new OrderItemHolder(convertView);
           convertView.setTag(holder);
       }else{
           holder = (OrderItemHolder) convertView.getTag();
       }

        holder.tvName.setText(orders.get(position).getFoodName());
        holder.tvPrice.setText("$"+ orders.get(position).getPrice());


        return convertView;
    }

    static class OrderItemHolder {
        TextView tvName;
        TextView tvPrice;

        OrderItemHolder(View view){
            tvName = (TextView) view.findViewById(R.id.tvItemName);
            tvPrice = (TextView) view.findViewById(R.id.tvItemPrice);
        }
    }
}
