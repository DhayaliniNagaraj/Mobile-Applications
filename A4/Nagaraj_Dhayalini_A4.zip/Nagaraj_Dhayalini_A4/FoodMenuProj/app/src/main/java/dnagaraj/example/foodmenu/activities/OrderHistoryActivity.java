package dnagaraj.example.foodmenu.activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

import dnagaraj.example.foodmenu.R;
import dnagaraj.example.foodmenu.adapters.OrderHistoryAdapter;
import dnagaraj.example.foodmenu.db.OrderDBModel;
import dnagaraj.example.foodmenu.db.OrderDataSource;

public class OrderHistoryActivity extends AppCompatActivity {

    ArrayList<OrderDBModel> data;
    ListView lsOrderHistory;
    LayoutInflater inflater = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_order_history);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        lsOrderHistory = (ListView) findViewById(R.id.lsOrderHistory) ;

        inflater = getLayoutInflater();
        lsOrderHistory.addHeaderView(inflater.inflate(R.layout.item_order_history_header,lsOrderHistory,false));
        data = (ArrayList<OrderDBModel>)getIntent().getExtras().getSerializable("order_history");


        if(data != null){
            OrderHistoryAdapter adapter = new OrderHistoryAdapter(data,this);
            lsOrderHistory.setAdapter(adapter);
        }

    }
}
