package dnagaraj.example.foodmenu.db;

import java.io.Serializable;

/**
 * Created by dhayalini on 27-02-2016.
 */
public class OrderDBModel implements Serializable{
    private int id;
    private String foodItems;
    private float totalPrice;
    private String timeStamp;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFoodItems() {
        return foodItems;
    }

    public void setFoodItems(String foodItems) {
        this.foodItems = foodItems;
    }

    public float getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(float totalPrice) {
        this.totalPrice = totalPrice;
    }

    public String getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(String timeStamp) {
        this.timeStamp = timeStamp;
    }

    @Override
    public String toString() {
        return "OrderDBModel{" +
                "id=" + id +
                ", foodItems='" + foodItems + '\'' +
                ", totalPrice=" + totalPrice +
                ", timeStamp='" + timeStamp + '\'' +
                '}';
    }
}
