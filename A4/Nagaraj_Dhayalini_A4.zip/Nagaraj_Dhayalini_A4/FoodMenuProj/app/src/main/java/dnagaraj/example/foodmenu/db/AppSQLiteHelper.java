package dnagaraj.example.foodmenu.db;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Created by dhayalini on 27-02-2016.
 */
public class AppSQLiteHelper extends SQLiteOpenHelper {

    public static final String TABLE_ORDERS = "orders";
    public static final String COLUMN_ID = "order_id";
    public static final String COLUMN_TIMESTAMP = "timestamp";
    public static final String COLUMN_ITEMS = "items";
    public static final String COLUMN_PRICE = "total_price";

    private static final String DATABASE_NAME = "foodmenu.db";
    private static final int DATABASE_VERSION = 1;

    // Database creation sql statement
    private static final String TABLE_CREATE = "create table "
            + TABLE_ORDERS + "(" + COLUMN_ID
            + " integer primary key autoincrement, " + COLUMN_PRICE
            + " real not null, "+COLUMN_ITEMS+" text not null, "+COLUMN_TIMESTAMP+" text not null);";

    public AppSQLiteHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase database) {
        database.execSQL(TABLE_CREATE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        Log.w(AppSQLiteHelper.class.getName(),
                "Upgrading database from version " + oldVersion + " to "
                        + newVersion + ", which will destroy all old data");
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ORDERS);
        onCreate(db);
    }
}
