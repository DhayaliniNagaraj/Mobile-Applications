package dnagaraj.example.foodmenu.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

import dnagaraj.example.foodmenu.R;
import dnagaraj.example.foodmenu.db.OrderDBModel;
import dnagaraj.example.foodmenu.models.OrderModel;

/**
 * Created by dhayalini on 12-02-2016.
 */
public class OrderHistoryAdapter extends BaseAdapter{

    ArrayList<OrderDBModel> orders;
    Context context;
    private LayoutInflater inflater;
    public OrderHistoryAdapter(ArrayList<OrderDBModel> orders, Context context){
        this.orders = orders;
        this.context = context;
        inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return orders.size();
    }

    @Override
    public Object getItem(int position) {
        return orders.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        OrderItemHolder holder = null;
       if(convertView == null){
           convertView = inflater.inflate(R.layout.item_order_history,parent,false);
           holder = new OrderItemHolder(convertView);
           convertView.setTag(holder);
       }else{
           holder = (OrderItemHolder) convertView.getTag();
       }

        holder.tvName.setText(orders.get(position).getFoodItems());
        holder.tvPrice.setText("$"+ orders.get(position).getTotalPrice());
        holder.tvTime.setText(orders.get(position).getTimeStamp());
        holder.tvOrderId.setText(orders.get(position).getId()+"");
        return convertView;
    }

    static class OrderItemHolder {
        TextView tvName;
        TextView tvPrice;
        TextView tvOrderId;
        TextView tvTime;

        OrderItemHolder(View view){
            tvName = (TextView) view.findViewById(R.id.tvItemName);
            tvPrice = (TextView) view.findViewById(R.id.tvItemPrice);
            tvOrderId = (TextView) view.findViewById(R.id.tvOrderId);
            tvTime = (TextView) view.findViewById(R.id.tvTime);
        }
    }
}
