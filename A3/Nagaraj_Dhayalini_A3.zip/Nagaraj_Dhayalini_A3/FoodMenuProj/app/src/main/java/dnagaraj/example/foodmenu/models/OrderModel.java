package dnagaraj.example.foodmenu.models;

import java.io.Serializable;

/**
 * Created by dhayalini on 19-02-2016.
 */
public class OrderModel implements Serializable{
    private int id;
    private String foodName;
    private float price;

    public OrderModel(String foodName, float price) {
        this.foodName = foodName;
        this.price = price;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFoodName() {
        return foodName;
    }

    public void setFoodName(String foodName) {
        this.foodName = foodName;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }
}
